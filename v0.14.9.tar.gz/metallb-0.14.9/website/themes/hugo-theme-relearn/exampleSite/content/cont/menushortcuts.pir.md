+++
title = "Menu extrrra shorrrtcuts"
weight = 6
+++
{{< piratify >}}