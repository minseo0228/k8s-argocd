+++
archetype = "chapter"
title = "Rambl'n"
weight = 2
+++
{{< piratify >}}