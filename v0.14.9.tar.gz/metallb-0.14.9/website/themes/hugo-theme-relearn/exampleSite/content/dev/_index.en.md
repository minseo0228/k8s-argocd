+++
archetype = "chapter"
hidden = true
title = "Development"
weight = 4
+++

This chapter contains information only needed for development and maintaining the theme.

{{%children containerstyle="div" style="h2" description="true" %}}
