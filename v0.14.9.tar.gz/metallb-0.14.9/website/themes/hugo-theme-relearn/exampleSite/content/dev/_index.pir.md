+++
archetype = "chapter"
hidden = true
title = "Development"
weight = 4
+++
{{< piratify >}}