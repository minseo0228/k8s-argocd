+++
categories = "basic"
disableToc = true
title = "Requirements"
weight = 10
+++

Thanks to the simplicity of Hugo, this page is as empty as this theme needs requirements.

Just download at least version {{% badge color="fuchsia" icon="fa-fw fab fa-hackerrank" title=" " %}}0.121.0{{% /badge %}} of the [Hugo binary](https://gohugo.io/getting-started/installing/) for your OS (Windows, Linux, Mac).

{{% figure src="magic.gif" link="https://gohugo.io" alt="Magic" caption="It's a kind of magic" %}}
