// SPDX-License-Identifier:Apache-2.0

package v1beta2

// Hub marks this type as a conversion hub.
func (*BGPPeer) Hub() {}
