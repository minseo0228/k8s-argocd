# Prometheus operator manifests

This is a stripped down prometheus operator deployment following the instructions at
https://github.com/prometheus-operator/kube-prometheus/blob/main/docs/customizing.md
